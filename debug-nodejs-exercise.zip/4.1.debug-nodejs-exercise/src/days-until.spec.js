const { daysUntil } = require('./days-until.js');

describe('daysUntil', () => {
  it('should return 5 for a date 5 days in the future', () => {
    pending('replace with logic for 5 days in the future');
  });

  it('should return 5 for a date 5 and 1/4 days in the future', () => {
    pending('replace with logic for 5 and 1/4 days in the future');

  });

  it('should return 5 for a date 4 and 3/4 days in the future', () => {
    pending('replace with logic for 4 and 3/4 days in the future');
  });
});
